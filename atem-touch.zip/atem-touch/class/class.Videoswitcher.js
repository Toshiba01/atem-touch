class Videoswitcher {
	
	changeProgramInput(input) {
		console.log("PGM: " + input);
	}

	changePreviewInput(input) {
		console.log("PVW: " + input);
	}

	cut(input) {
		console.log("CUT: " + input);
	}

	setTransitionPosition(input) {
		// 100 % * 100 = 10.000 <- expected final value for a transition
		this.switcher.setTransitionPosition(input*100).then((res) => {
			// console.log(res)
		})
		// console.log(this.switcher.state)
	}

	tapped(input) {
		if(1 == 1) {
			// let toBePreview = this.state.program;
			this.changePreviewInput(input);
			// this.changePreviewInput(toBePreview);
			
			return true;
		} else {
			this.changeProgramInput(input);
		}
	}
}




